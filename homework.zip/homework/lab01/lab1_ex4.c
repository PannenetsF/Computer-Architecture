#include <stdio.h>

int source[] = {3, 1, 4, 1, 5, 9, 0};
int dest[10];

int main ( ) {
    int k;
    for (k=0; source[k]!=0; k++) {
	dest[k] = source[k];
    }
    printf ("%d values copied\n", k);
    return 0;
}